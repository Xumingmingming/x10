#!/usr/bin/env bash
rm -rf logs
rm -f sample.csv
